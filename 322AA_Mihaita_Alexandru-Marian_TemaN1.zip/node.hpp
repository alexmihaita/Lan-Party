class node {
public:
        Team data;
        node* left;
        node* right;
    };
